# Übersetzen der C-Header
```
h2pas -p -T -d -c -e xxx.h
```

